//var baseUrl=$("#baseUrl").val(),
//alert(base_url);
var baseUrl = base_url;
array=[ {
    name: "registrationForm", value: baseUrl+"registerUser"
}

,
{
    name: "editBasicInfo", value: baseUrl+"my_account/updateBasicInfo"
}

];