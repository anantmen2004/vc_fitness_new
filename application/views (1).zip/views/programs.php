<?php 
  $this->load->view('templates/header')
?> 
            
<?php 
  $this->load->view('templates/footer')
?>