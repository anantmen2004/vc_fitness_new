  <!-- footer starts here -->
  <footer id="footer">
    <div class="footer-widgets-wrapper">
      <div class="container">
        <div class="column dt-sc-one-fourth first">
          <aside class="widget widget_text">
            <div class="textwidget">
              <h3 class="widgettitle"><span class="fa fa-user"></span>About Us</h3>
              <p>I would like to share my journey from a middle class family, one normal guy to a professional Bodybuilder to India's no. 1 celebrity trainer and Fitness expert.

</p>
              <p>From my childhood till my college time I was very thin and underweight kid in the family. All friends and relatives used to tease me as 'Sukda' means very thin guy. But in my father's limited salary we could not afford to have even one time milk.</p>
            </div>
          </aside>
        </div>
        <div class="column dt-sc-one-fourth">
          <aside class="widget widget_text">
            <h3 class="widgettitle"><span class="fa fa-link"></span>Useful Links</h3>
            <div class="textwidget">
              <ul>
                <li><a href="#">Products</a></li>
                <li><a href="<?php echo base_url('faq/faqView');?>">Faq's</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms Of Use</a></li>
                <li><a href="#">Blogs</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div>
          </aside>
        </div>
        <div class="column dt-sc-one-fourth">
          <aside class="widget widget_tweetbox">
            <h3 class="widgettitle"><span class="fa fa-twitter"></span>Twitter Updates</h3>
            <div class="tweet_list"> </div>
          </aside>
        </div>
        <div class="column dt-sc-one-fourth">
          <aside class="widget widget_recent_entries">
            <h3 class="widgettitle"><span class="fa fa-calendar"></span>Upcoming Events</h3>
            <div class="recent-posts-widget">
              <ul>
                <li> <a href="#" class="entry-thumb"><img src="<?php echo base_url();?>public/images/blog-thumb.jpg" alt="" title=""></a>
                  <h4><a href="#">Training with Dumbell</a></h4>
                  <div class="entry-metadata">
                    <p class="date">26 May 2014</p>
                  </div>
                </li>
                <li> <a href="#" class="entry-thumb"><img src="<?php echo base_url();?>public/images/blog-thumb1.jpg" alt="" title=""></a>
                  <h4><a href="#">Create the Adonis Effect</a></h4>
                  <div class="entry-metadata">
                    <p class="date">24 May 2014</p>
                  </div>
                </li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
      <div class="social-media-container">
        <div class="social-media">
          <div class="container">
            <div class="dt-sc-contact-info dt-phone">
              <p><i class="fa fa-phone"></i> <span>022 65556512</span> </p>
            </div>
            <ul class="dt-sc-social-icons">
              <li class="facebook"><a href="#" class="fa fa-facebook"></a></li>
              <li class="google"><a href="#" class="fa fa-google-plus"></a></li>
              <li class="twitter"><a href="#" class="fa fa-twitter"></a></li>
              <li class="youtube"><a href="#" class="fa fa-youtube"></a></li>
              <li class="rss"><a href="#" class="fa fa-rss"></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="copyright">
      <div class="container">
        <ul class="footer-links">
          <li><a href="#"> About Us </a></li>
          <li><a href="#"> Help Centre </a></li>
          <li><a href="#"> Site Map </a></li>
        </ul>
        <p>&copy; 2016 - FitnessIndia. By <a href="http://proxanttech.com/" target="_blank">Proxant</a></p>
      </div>
    </div>
  </footer>
  <!-- footer ends here --> 
  
</div>
<!-- **Inner Wrapper - End** -->
</div>
<!-- **Wrapper - End** --> 

<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.ui.totop.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/custom.js"></script>


<!--show-hide-data--->
<script language="JavaScript">
function ShowHide(divId)
{
if(document.getElementById(divId).style.display == 'none')
{
document.getElementById(divId).style.display='block';
}
else
{
document.getElementById(divId).style.display = 'none';
}
}
</script>
<!--show hide-data-end-->
 

<!-- slider-corporate --> 
<script type="text/javascript">
  
  $(function(){


  $('#marquee-vertical').marquee();  
  $('#marquee-horizontal').marquee({direction:'horizontal', delay:0, timing:50});  

});

</script> 
<!-- slider-corporate-end -->  
<!-- slider-video --> 
<script>
$(document).ready(function() {
  $('#media').carousel({
    pause: true,
    interval: false,
  });
});
</script>
<script>
$(document).ready(function() {
  $('#media').carousel({
    pause: true,
    interval: false,
  });
    $('#media1').carousel({
    pause: true,
    interval: false,
  });
     $('#media2').carousel({
    pause: true,
    interval: false,
  });
    $('#media3').carousel({
    pause: true,
    interval: false,
  });
   $('#media4').carousel({
    pause: true,
    interval: false,
  }); 
  $('#media5').carousel({
    pause: true,
    interval: false,
  }); 
   $('#media6').carousel({
    pause: true,
    interval: false,
  });
  $('#media7').carousel({
    pause: true,
    interval: false,
  });
  $('#media8').carousel({
    pause: true,
    interval: false,
  });
  $('#media9').carousel({
    pause: true,
    interval: false,
  }); 
   $('#media10').carousel({
    pause: true,
    interval: false,
  });
  $('#media11').carousel({
    pause: true,
    interval: false,
  });
  $('#media12').carousel({
    pause: true,
    interval: false,
  });
   $('#media13').carousel({
    pause: true,
    interval: false,
  });
  $('#media14').carousel({
    pause: true,
    interval: false,
  }); 
   $('#media15').carousel({
    pause: true,
    interval: false,
  });
  $('#media16').carousel({
    pause: true,
    interval: false,
  });
  $('#media17').carousel({
    pause: true,
    interval: false,
  });
   $('#media18').carousel({
    pause: true,
    interval: false,
  });
   $('#media30').carousel({
    pause: true,
    interval: false,
  });
   $('#media31').carousel({
    pause: true,
    interval: false,
  });
   $('#media32').carousel({
    pause: true,
    interval: false,
  });
  
   $('#media33').carousel({
    pause: true,
    interval: false,
  });
   $('#media34').carousel({
    pause: true,
    interval: false,
  });
   $('#media35').carousel({
    pause: true,
    interval: false,
  });
   $('#media36').carousel({
    pause: true,
    interval: false,
  });
   $('#media37').carousel({
    pause: true,
    interval: false,
  });
   $('#media38').carousel({
    pause: true,
    interval: false,
  });
   $('#media39').carousel({
    pause: true,
    interval: false,
  });
   $('#media40').carousel({
    pause: true,
    interval: false,
  });
   $('#media41').carousel({
    pause: true,
    interval: false,
  });
   $('#media42').carousel({
    pause: true,
    interval: false,
  });
   $('#media43').carousel({
    pause: true,
    interval: false,
  });
   $('#media44').carousel({
    pause: true,
    interval: false,
  });
   $('#media45').carousel({
    pause: true,
    interval: false,
  });
   $('#media46').carousel({
    pause: true,
    interval: false,
  });
   $('#media47').carousel({
    pause: true,
    interval: false,
  });
   $('#media48').carousel({
    pause: true,
    interval: false,
  });
   $('#media49').carousel({
    pause: true,
    interval: false,
  });
});
</script> 
 <script>
    $(document).ready(function() {
        $(".gallery a").ClassyBox();
        $(".player a").ClassyBox();
        $(".video a").ClassyBox({
            width: 900,
            title: 0
        });
        $("#frame").ClassyBox({
            iframe: 1,
            social: 0,
            height: 600,
            width: 900
        });
        $("#ajax").ClassyBox({
            height: 450,
            width: 555,
            ajaxSuccess: function(data) {
                $(".classybox-wrap .content").append(data);
            }
        });
        $('a[href*="vimeo"], a[href*="vevo"], a[href*="dailymotion"], a[href*="5min"], a[href*="ustream"], a[href*="metacafe"], a[href*="hell"], a[href*="myspace"]').ClassyBox({
            height: 500,
            width: 850
        });
        $(window).ClassyBox({
            autoDetect: 1
        });
    });
</script>
<!-- slider-video-end --> 
<!-- **jQuery** -->
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.prettyPhoto.js"></script>
 
<!-- **jQuery** -->
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery-migrate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.gmap.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/contact.js"></script>
<!-- **jQuery** --> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.plugins.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.nicescroll.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.fancybox.pack.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.carouFredSel-6.2.1-packed.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/pace.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.tabs.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.tipTip.minified.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.ui.totop.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery-transit-modified.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/layerslider.kreaturamedia.jquery.js"></script> 
<script type='text/javascript' src="<?php echo base_url();?>public/js/greensock.js"></script> 
<script type='text/javascript' src="<?php echo base_url();?>public/js/layerslider.transitions.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/retina.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/twitter/jquery.tweet.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.validate.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>public/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/form-validation.js"></script> 
</body>
</html>