    <div id="main"> 
      <!-- main-content starts here -->
      <div id="main-content">
        <section id="primary" class="content-full-width">
          <div class="dt-sc-hr-invisible-small"></div>
          <div class="dt-sc-hr-invisible-normal"></div>
          <!-- Pricintable type3 starts here -->
          <div class="fullwidth-section">
            <div class="container">
            <h3 class="border-title"> <span>Upcoming Events </span> </h3>
             <div class="tpl-blog-holder apply-isotope">
                            <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-gallery">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog1.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail.html">Best Cardio Exercise</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p> 
                                                <a href="blog-detail.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-standard">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-left-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog2.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-left-sidebar.html">How to Eat for bulking you up?</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p>
                                                <a href="blog-detail-with-left-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-link">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-right-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog3.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-right-sidebar.html">Training with Dumbell</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p>
                                                <a href="blog-detail-with-right-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-audio">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog4.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail.html">Young Women Doing Abdominal</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p>
                                                <a href="blog-detail.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-quote">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-left-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog5.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-left-sidebar.html">Aerobic Pilates</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p>
                                                <a href="blog-detail-with-left-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-video sticky">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-right-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/blog6.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                              <div class="featured-post"><span>Featured</span></div>
                                                <div class="clear"></div>
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-right-sidebar.html">Gym Personal Trainer</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. Sed ipsum odio, condimentum nec hendrerit feugiat, convallis et dui. Etiam tempus magna facilisis, faucibus est placerat, egestas turpis....</p>
                                                <a href="blog-detail-with-right-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <!-- <div class="pagination">
                                <div class="prev-post">
                                    <a href="#"><span class="fa fa-angle-double-left"></span> Prev</a>
                                </div>
                                <ul class="">
                                    <li class="active-page">1</li>
                                    <li><a class="inactive" href="#">2</a></li>
                                </ul>
                                <div class="next-post">
                                    <a href="#">Next <span class="fa fa-angle-double-right"></span></a>
                                </div>
                            </div> -->
               
            </div>
          </div>
          
          <!-- support starts here -->
          <div class="dt-sc-hr-invisible-large"></div>
        </section>
      </div>
      <!-- main-content ends here --> 
    </div>
   