<div id="main"> 
      <!-- main-content starts here -->
      <div id="main-content">
        <section id="primary" class="content-full-width">
          <div class="dt-sc-hr-invisible-small"></div>
          <div class="dt-sc-hr-invisible-normal"></div>
          <!-- Pricintable type3 starts here -->
          <div class="fullwidth-section">
            <div class="container">
             
              <div class="column dt-sc-one-column first">
                <div class="dt-sc-clear"> </div>
                 <section id="secondary-left" class="secondary-sidebar secondary-has-left-sidebar">                            
                        	<aside class="widget widget_popular_entries">
                                <div class="widgettitle">
	                                <h3>Estore <small>Fitness Products</small></h3>
                                    <span></span>
                                </div>
                                <div class="recent-gallery-widget">
                                    <ul>
                                        <li>
                                            <a class="entry-thumb" href="#"><img alt="Training with Dumbell" src="<?php echo base_url();?>public/images/blog-thumb.jpg"></a>
                                            <h6><a href="#">Training with Dumbell</a></h6>
                                            <p>Nulla luctus ligula ut metus iaculis fringilla. Aliquam venenatis,...</p>
                                        </li>
                                        <li>
                                            <a class="entry-thumb" href="#"><img alt="Create the Adonis Effect" src="<?php echo base_url();?>public/images/blog-thumb1.jpg"></a>
                                            <h6><a href="#">Create the Adonis Effect</a></h6>
                                            <p>Nulla luctus ligula ut metus iaculis fringilla. Aliquam venenatis,...</p>
                                        </li>
                                    </ul>
                                </div>
                            </aside>
                            <aside class="widget widget_categories">
                                <div class="widgettitle">
	                                <h3>Programs</h3>
                                    <span></span>
                                </div>
                                <ul>
                                    <li class="cat-item"><a title="#" href="#">Weight Training<span> 4</span></a></li>
                                    <li class="cat-item"><a title="#" href="#"> Gadgets Training <span> 8</span></a></li>
                                    <li class="cat-item"><a title="#" href="#">Functional Training<span> 2</span></a></li>
                                    <li class="cat-item"><a title="#" href="#">Calithenic & Parkour<span> 8</span></a></li>
                                    <li class="cat-item"><a title="#" href="#">Yoga<span> 3</span></a></li>
                                </ul>
							</aside>
                            <aside class="widget widget_search">
                                <div class="widgettitle">
	                                <h3>Subscribe</h3>
                                    <span></span>
                                </div>
                                <form action="#" id="searchform" method="get">
                                    <input type="text" placeholder="Enter Email" class="text_input" value="" name="s" id="s">
                                    <input type="submit" value="submit" name="submit" class="dt-sc-button small">
                                </form>
                            </aside>
                            <aside class="widget widget_archive">
                                <div class="widgettitle">
	                                <h3>About</h3>
                                    <span></span>
                                </div>
                                <ul>
                                    <li><a href="about.html">Biography<span> More..</span></a></li>
                                    <li><a href="#">Press Releases<span>   More..</span></a></li>
                                    <li><a href="testimonials.html">Corporate Clients<span>  More..</span></a></li>
                                    <li><a href="#">Experience<span>  More..</span></a></li>
                                    <li><a href="#">Fitness facts<span>  More..</span></a></li>
                                </ul>
                            </aside>
                            <aside class="widget widget_social_profile">
                                <div class="widgettitle">
	                                <h3>Social Widget</h3>
                                    <span></span>
                                </div>                
                                <ul class="dt-sc-social-icons">
                                    <li class="facebook"><a href="#" class="fa fa-facebook"></a></li>
                                    <li class="twitter"><a href="#" class="fa fa-twitter"></a></li>
                                    <li class="flickr"><a href="#" class="fa fa-flickr"></a></li>
                                    <li class="youtube"><a href="#" class="fa fa-youtube"></a></li>
                                </ul>
	                        </aside>
                        </section>
	                    <section id="primary" class="page-with-sidebar page-with-left-sidebar">
                         <h3 class="border-title"> <span> Awards & Achivement </span> </h3>
                        	<div class="tpl-blog-holder apply-isotope">
	                        	<div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-quote">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail.html">Best Cardio Exercise</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel.  condimentum nec hendrerit feugiat....</p>
                                                <a href="blog-detail.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-standard sticky">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-left-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                            	<div class="featured-post"><span>Featured</span></div>
                                                <div class="clear"></div>
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-left-sidebar.html">How to Eat for bulking you up?</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt. condimentum nec hendrerit feugiat, convallis et dui....</p>
                                                <a href="blog-detail-with-left-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-gallery">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-right-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-right-sidebar.html">Training with Dumbell</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel.  condimentum nec hendrerit feugiat, convallis et dui.....</p>
                                                <a href="blog-detail-with-right-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-aside">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>

                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail.html">Young Women Doing Abdominal</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. condimentum nec hendrerit feugiat, convallis et dui....</p>
                                                <a href="blog-detail.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-chat">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-left-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="blog-detail-with-left-sidebar.html">Aerobic Pilates</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. condimentum nec hendrerit feugiat, convallis et dui....</p>
                                                <a href="blog-detail-with-left-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="dt-sc-one-column column blog-thumb">
                                    <article class="blog-entry format-audio">
                                        <div class="blog-entry-inner">
                                            <div class="entry-thumb">
                                                <a href="blog-detail-with-right-sidebar.html">
                                                    <img title="" alt="" src="<?php echo base_url();?>public/images/award.jpg">
                                                    <div class="blog-overlay"><span class="image-overlay-inside"></span></div>
                                                </a>
                                                <div class="entry-meta">
                                                    <div class="date">
                                                        <span>21</span>
                                                        mar<br>
                                                        2014
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="entry-metadata">
                                                <p class="tags"><a href="#">Workout </a> / <a href="#"> Diet</a></p>
                                                <h4><a href="#">Gym Personal Trainer</a></h4>
                                                <p>Mauris dictum, purus non commodo tincidunt, diam turpis mattis leo, id aliquet leo tellus at urna. In placerat pretium magna, nec egestas sapien feugiat vel. condimentum nec hendrerit feugiat, convallis et dui....</p>
                                                <a href="blog-detail-with-right-sidebar.html">Read More <i class="fa fa-angle-double-right"></i></a>
                                            </div>
                                        </div>
                                    </article>
                            	</div>
                            </div>
                            <div class="pagination">
                                <div class="prev-post">
                                    <a href="#"><span class="fa fa-angle-double-left"></span> Prev</a>
                                </div>
                                <ul class="">
                                    <li class="active-page">1</li>
                                    <li><a class="inactive" href="#">2</a></li>
                                </ul>
                                <div class="next-post">
                                    <a href="#">Next <span class="fa fa-angle-double-right"></span></a>
                                </div>
							</div>
	                    </section>
              </div>
            </div>
          </div>
          
          <!-- support starts here -->
          <div class="dt-sc-hr-invisible-large"></div>
        </section>
      </div>
      <!-- main-content ends here --> 
    </div>