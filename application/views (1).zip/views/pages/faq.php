<div id="main">
                <!-- main-content starts here -->
                <div id="main-content">
                    <section id="primary" class="content-full-width">
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="container">
                            <h3 class="border-title"> <span> Faq's </span></h3>
                            <div class="dt-sc-one-fourth column first">
                                <div class="widget quick_links">
                                    <ul>
                                        <li><a href="#">Additional Support Links</a></li>
                                        <li><a href="#">Knowledge Base</a></li>
                                        <li><a href="#">Pricing and features</a></li>
                                        <li><a href="#">Change payment information</a></li>
                                        <li><a href="#">Cancel your account</a></li>
                                        <li><a href="#">Visit our support page</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="dt-sc-three-fourth column">
                           <!--     <form class="faq-search">
                                    <input type="text" placeholder="Search for help by topics, keywords or phrases">
                                    <input type="submit" value="Search for Help">
                                </form>-->
                                <h4>General Fitness Related FAQ's</h4>
                                <div class="dt-sc-toggle-frame-set">
                                    <h5 class="dt-sc-toggle-accordion active"><a href="#">3 days a week program</a></h5>
                                    <div class="dt-sc-toggle-content">
                                        <div class="block">
                                            <p>There are many <a href="#">variations of passages</a> of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first <a href="#">true</a> generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic </p>
                                            <div class="dt-sc-hr-invisible-small"></div>
                                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis <a href="#">praesentium</a> voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident. </p>
                                        </div>
                                    </div>
                                    <h5 class="dt-sc-toggle-accordion "><a href="#">Diet program Included</a></h5>
                                    <div class="dt-sc-toggle-content">
                                        <div class="block">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.  It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic.</p>
                                        </div>
                                    </div>
                                    <h5 class="dt-sc-toggle-accordion "><a href="#">Professional Trainers</a></h5>
                                    <div class="dt-sc-toggle-content">
                                        <div class="block">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first <a href="#">true</a> generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. </p>
                                        </div>
                                    </div>
                                    <h5 class="dt-sc-toggle-accordion "><a href="#">Convienent  Timing</a></h5>
                                    <div class="dt-sc-toggle-content">
                                        <div class="block">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first <a href="#">true</a> generator on the Internet.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="dt-sc-hr-invisible"></div>
                                <h4>Health Realted FAQ's</h4>
                                <h5 class="dt-sc-toggle"><a href="#">Who Can Join Fitness Club?</a></h5>
                                <div class="dt-sc-toggle-content">
                                    <div class="block">
                                        Toggle 1 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                                    </div>
                                </div>
                                <h5 class="dt-sc-toggle"><a href="#">I have Hepatitis B. Can i Join the Fitness Zone?</a></h5>
                                <div class="dt-sc-toggle-content">
                                    <div class="block">
                                        Toggle 2 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                                    </div>
                                </div>
                                <h5 class="dt-sc-toggle"><a href="#">Who will be my Personal Trainer?</a></h5>
                                <div class="dt-sc-toggle-content">
                                    <div class="block">
                                        Toggle 3 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                                    </div>
                                </div>
                            </div>
                            <div class="dt-sc-hr-invisible-medium"></div>
                            <h5 class="aligncenter">Still have Questions</h5>
                            <div class="dt-sc-hr-invisible-small"></div>
                            <div class="dt-sc-one-third column first">
                                <div class="dt-sc-contact-info aligncenter">
                                    <h5><a href="#">Check our FAQ's</a></h5>
                                    <p>Check out the Frequently asked Questions</p>
                                </div>
                            </div>
                            <div class="dt-sc-one-third column">
                                <div class="dt-sc-contact-info aligncenter">
                                    <h5><a href="#">Talk to  a Professional Trainer</a></h5>
                                    <p>Just Call +41 (0)51 243 652 121 for an advice</p>
                                </div>
                            </div>
                            <div class="dt-sc-one-third column">
                                <div class="dt-sc-contact-info aligncenter">
                                    <h5><a href="#">Give us a message</a></h5>
                                    <p>Email us at: <a href="#">manager@fitnesszone.com</a></p>
                                </div>
                            </div>
                        </div>
                        <!-- support starts here -->
                        <div class="dt-sc-hr-invisible-large"></div>
                    </section>
                </div>  