<div id="main"> 
      <!-- main-content starts here -->
      <div id="main-content">
        <section id="primary" class="content-full-width">
          <div class="dt-sc-hr-invisible-small"></div>
          <div class="dt-sc-hr-invisible-normal"></div>
          <!-- Pricintable type3 starts here -->
          <div class="fullwidth-section">
            <div class="container">
              <h3 class="border-title"> <span> Testimonials </span> </h3>
              <div class="column dt-sc-one-column first">
                <div class="dt-sc-clear"> </div>
                 <div class='dt-sc-tabs-vertical-container'>
              <ul class='dt-sc-tabs-vertical-frame'>
                <li><a href="#"> John Abraham </a></li>
                <li><a href="#"> Shilpa Shetty Kundra </a></li>
                <li><a href="#"> Ritesh Deshmukh </a></li>
                <li><a href="#"> Anant Ambani</a></li>
              </ul>
              <div class="dt-sc-tabs-vertical-frame-content">
                <div class="intro-text type2">
                  <div class="column dt-sc-one-column first"> <img class="alignleft" title="" alt="" src="<?php echo base_url();?>public/images/team5.jpg">
                    <h4>John Abraham</h4>
                    <p class="text-justify">Force movie John had to put on Muscle Mass. With Vinod's Training and Diet plan within 7 to 8 months John could achieve his target of gaining the Muscle mass. After Force John had to have Lean Physique for Shoot out at Wadala & Race- 2.It was not difficult for Vinod Channa to bring him back to Leaner size. Vinod Changed his Workout routine also the Diet which can make John look Leaner. Vinod has successfully trained John for his macho look Desi Boyz as well. <a onclick ="javascript:ShowHide('HiddenDiv')" href="javascript:;"  data-hover="Read More"> Read More...</a></p>
                    <div class="mid" id="HiddenDiv" style="DISPLAY: none" >
                      <div class="dt-sc-hr-invisible-small"> </div>
                      <p class="text-justify"> I am thankful to Vinod not only for training me but giving me tips which will help me maintain my fitness not today or tomorrow but forever.</p>
                    </div>
                   </div>
                   
                </div>
                <!-- Fitness msg starts here --> 
                 <div class="carousel slide media-carousel" id="media">
                      <div class="carousel-inner video">
                        <div class="item  active">
                          <div class="row">
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/john/image5.jpg"><img alt="" src="<?php echo base_url();?>public/images/john/image5.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/john/image4.jpg"><img alt="" src="<?php echo base_url();?>public/images/john/image4.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/john/image3.jpg"></a> </div>
                          </div>
                        </div>
                        <div class="item">
                          <div class="row">
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/john/image2.jpg"><img alt="" src="<?php echo base_url();?>public/images/john/image2.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/john/image6.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/john/image1.jpg"><img alt="" src="<?php echo base_url();?>public/images/john/image1.jpg"></a> </div>
                          </div>
                        </div>
                      </div>
                      <a data-slide="prev" href="#media" class="left carousel-control">‹</a> <a data-slide="next" href="#media" class="right carousel-control">›</a> </div>
              </div>
              <div class="dt-sc-tabs-vertical-frame-content">
                <div class="intro-text type2"> <img class="alignleft" title="" alt="" src="<?php echo base_url();?>public/images/team4.jpg">
                  <h4>Shilpa Shetty Kundra</h4>
                  <p class="text-justify"> Shilpa Shetty Kundra lost 14 kg of her post pregnancy weight in 2 and half month with Vinod's Training + Diet. </p>
                 </div>
                 <div class="carousel slide media-carousel" id="media1">
                    <div class="carousel-inner video">
                      <div class="item  active">
                        <div class="row">
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/shilpa-shetty/image1.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image1.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/shilpa-shetty/image2.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image2.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/shilpa-shetty/image3.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image3.jpg"></a> </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/shilpa-shetty/image4.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image4.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail youtube-btn" href="<?php echo base_url();?>public/images/shilpa-shetty/image5.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image5.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/shilpa-shetty/image6.jpg"><img alt="" src="<?php echo base_url();?>public/images/shilpa-shetty/image6.jpg"></a> </div>
                        </div>
                      </div>
                    </div>
                    <a data-slide="prev" href="#media1" class="left carousel-control">‹</a> <a data-slide="next" href="#media1" class="right carousel-control">›</a> </div>
               </div>
              <div class="dt-sc-tabs-vertical-frame-content">
                <div class="intro-text type2"> <img class="alignleft" title="" alt="" src="<?php echo base_url();?>public/images/team3.jpg">
                  <h4>Ritesh Deshmukh</h4>
                  <p class="text-justify"> Time for fitness -no one better than - @ChannaVinod - no pain no gain</p> 
                </div>
                 <div class="carousel slide media-carousel" id="media2">
                    <div class="carousel-inner video">
                      <div class="item  active">
                        <div class="row">
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image2.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image2.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image1.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image1.jpg"></a> </div>
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image3.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image3.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image4.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image4.jpg"></a> </div>
                          <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/ritesh/image5.jpg"><img alt="" src="<?php echo base_url();?>public/images/ritesh/image5.jpg"></a> </div>
                        </div>
                      </div>
                    </div>
                    <a data-slide="prev" href="#media2" class="left carousel-control">‹</a> <a data-slide="next" href="#media2" class="right carousel-control">›</a> </div>
              </div>
              
              <div class="dt-sc-tabs-vertical-frame-content">
                <div class="intro-text type2">
                  <div class="column dt-sc-one-column first"> <img class="alignleft" title="" alt="" src="<?php echo base_url();?>public/images/team2.jpg">
                    <h4>Anant Ambani</h4>
                    <p class="text-justify">Anant Ambani sheds 108 kilos and proves Impossible is Nothing if one focuses it.

Anant's hardwork and dedication combined with Vinod Channa's (India's Best Celebrity Fitness Trainer) knowledge and experience of more then 20 years in fitness industry, 16 different fitness techniques made him stronger and achieve his target.

 <a onclick ="javascript:ShowHide('HiddenDiv1')" href="javascript:;"  data-hover="Read More"> Read More...</a></p>
                    <div class="mid" id="HiddenDiv1" style="DISPLAY: none" >
                      <div class="dt-sc-hr-invisible-small"> </div>
                      <p class="text-justify"> If you have the guts to do hardwork, sacrifice, determination, dedication and perfect knowledge you can achieve anything says Anant Ambani's fitness expert Vinod Channa.

He has lost a staggering 108 kilos in less than 18 months. As he was determined to lose weight in the most natural and safest way possible, he followed a strict diet and exercised for five-six hours every day. His daily exercise regimen included a 21-km walk, followed by yoga, weight training, functional training and low to high-intensity cardio exercises. He stuck to a zero-sugar, low-carb diet along with adequate fats and proteins.

I am very proud to be fitness expert of Anant.</p>
                    </div>
                   </div>
                </div>
                <!-- Fitness msg starts here --> 
                <div class="carousel slide media-carousel" id="media3">
                      <div class="carousel-inner video">
                        <div class="item  active">
                          <div class="row">
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image5.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image5.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image6.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image6.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image4.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image4.jpg"></a> </div>
                          </div>
                        </div>
                        <div class="item">
                          <div class="row">
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image3.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image3.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image2.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image2.jpg"></a> </div>
                            <div class="col-md-4"> <a class="thumbnail" href="<?php echo base_url();?>public/images/anant-ambani/image1.jpg"><img alt="" src="<?php echo base_url();?>public/images/anant-ambani/image1.jpg"></a> </div>
                          </div>
                        </div>
                      </div>
                      <a data-slide="prev" href="#media3" class="left carousel-control">‹</a> <a data-slide="next" href="#media3" class="right carousel-control">›</a> </div>
              </div>
            </div>
              </div>
            </div>
          </div>
          
          <!-- support starts here -->
          <div class="dt-sc-hr-invisible-large"></div>
        </section>
      </div>
      <!-- main-content ends here --> 
    </div>