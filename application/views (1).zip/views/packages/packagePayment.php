<div id="main">
                <!-- main-content starts here -->
                <div id="main-content">
                    <section id="primary" class="content-full-width">
                        <div class="dt-sc-hr-invisible-small"></div>
                        <div class="dt-sc-hr-invisible-normal"></div>
                        <!-- Pricintable type3 starts here -->
                        <div class="fullwidth-section">
                            <div class="container">
                            	<h3 class="border-title"> <span> Payment Gateway</span> </h3>
                               
                            </div>
						</div>

						
                    </section>
				</div>
                <!-- main-content ends here -->
            </div>