<div id="main">
  <div id="main-content">
   <section id="primary" class="content-full-width">
    <div class="dt-sc-hr-invisible"></div>
    <div class="fullwidth-section dt-sc-paralax full-pattern3">
      <div class="container">
        <h3 class="border-title"> <span>Product Return </span> </h3>
        <div class="intro-text type2 animate" data-animation="fadeInUp" data-delay="100">
         <div class="dt-sc-one first">
          <p>Thank you for submitting your return request. Your request has been sent to the relevant department for processing.

            You will be notified via e-mail as to the status of your request..</p>
          </div>
          <a href="<?php echo base_url('product/productView') ?>" class="dt-sc-button small pull-right" data-hover="Read More">Continue</a>

        </div>
      </div>
    </div>
    <div class="dt-sc-hr-invisible-small"></div>
  </section>
</div>
</div>
